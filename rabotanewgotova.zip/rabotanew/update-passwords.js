// Создайте файл update-passwords.js
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'rabotanew',
    password: 'root',
    port: 5432,
});

async function updatePasswords() {
    const hash = await bcrypt.hash('12345', 10);
    await pool.query('UPDATE users SET password_hash = $1', [hash]);
    console.log('✅ Пароли обновлены на: 12345');
    process.exit();
}

updatePasswords();