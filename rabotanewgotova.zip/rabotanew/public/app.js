// Проверка авторизации
const token = localStorage.getItem('token');
const role = localStorage.getItem('role');
const username = localStorage.getItem('username');
const firstName = localStorage.getItem('firstName');
const lastName = localStorage.getItem('lastName');

if (!token) {
    window.location.href = 'login.html';
}

// Отображение пользователя
const userInfo = document.getElementById('userInfo');
const roleLabels = {
    'STORE_MANAGER': 'Управляющий магазином',
    'OFFICE_MANAGER': 'Менеджер офиса', 
    'HR_SPECIALIST': 'HR-специалист'
};
userInfo.innerHTML = `👤 ${firstName || ''} ${lastName || ''} <span class="role-badge">${roleLabels[role] || role}</span>`;

// Выход
document.getElementById('logoutBtn')?.addEventListener('click', () => {
    localStorage.clear();
    window.location.href = 'login.html';
});

// Загрузка задач
async function loadTasks() {
    const container = document.getElementById('tasksContainer');
    container.innerHTML = '<div class="text-center">Загрузка...</div>';
    
    try {
        const response = await fetch('/api/tasks', {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Ошибка загрузки');
        
        const tasks = await response.json();
        container.innerHTML = '';

        if (tasks.length === 0) {
            container.innerHTML = '<div class="alert alert-info">Задач нет</div>';
            return;
        }

        const statusLabels = {
            'NEW': 'Новая', 'IN_PROGRESS': 'В работе', 'ASSIGNED': 'Назначена',
            'RECRUITMENT_PENDING': 'Подбор', 'CANCELLED': 'Отменена', 'CLOSED': 'Закрыта'
        };
        const statusClass = {
            'NEW': 'bg-secondary', 'IN_PROGRESS': 'bg-primary', 'ASSIGNED': 'bg-info',
            'RECRUITMENT_PENDING': 'bg-warning', 'CANCELLED': 'bg-danger', 'CLOSED': 'bg-success'
        };

        tasks.forEach(task => {
            const col = document.createElement('div');
            col.className = 'col-md-6 col-lg-4';
            col.innerHTML = `
                <div class="card task-card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h6 class="fw-bold">${escapeHtml(task.title)}</h6>
                            <span class="badge ${statusClass[task.status] || 'bg-secondary'}">
                                ${statusLabels[task.status] || task.status}
                            </span>
                        </div>
                        <p class="text-muted small">${escapeHtml(task.description)}</p>
                        <small class="text-muted">📅 ${task.start_date} — ${task.end_date}</small>
                        ${task.requirements ? `<p class="mt-2"><small><strong>Требования:</strong> ${escapeHtml(task.requirements)}</small></p>` : ''}
                        ${role === 'STORE_MANAGER' ? `<button class="btn btn-danger btn-sm mt-2 delete-btn" data-id="${task.id}">🗑️ Удалить</button>` : ''}
                    </div>
                </div>
            `;
            container.appendChild(col);
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', e => deleteTask(e.target.dataset.id));
        });

    } catch (error) {
        container.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
        if (error.message.includes('401') || error.message.includes('403')) {
            localStorage.clear();
            window.location.href = 'login.html';
        }
    }
}

// Добавление задачи
document.getElementById('addBtn')?.addEventListener('click', async () => {
    const title = document.getElementById('taskTitle')?.value.trim();
    const description = document.getElementById('taskDesc')?.value.trim();
    const startDate = document.getElementById('taskStartDate')?.value;
    const endDate = document.getElementById('taskEndDate')?.value;
    const requirements = document.getElementById('taskRequirements')?.value.trim();

    if (!title) return alert('Введите название задачи');

    try {
        const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ title, description, startDate, endDate, requirements })
        });

        if (!response.ok) throw new Error('Не удалось создать');
        
        // Очистка полей
        ['taskTitle','taskDesc','taskStartDate','taskEndDate','taskRequirements'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
        
        loadTasks();
    } catch (error) {
        alert(error.message);
    }
});

// Удаление задачи
async function deleteTask(id) {
    if (!confirm('Удалить задачу?')) return;
    
    try {
        const response = await fetch(`/api/tasks/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) throw new Error('Ошибка удаления');
        loadTasks();
    } catch (error) {
        alert(error.message);
    }
}

// Защита от XSS
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Запуск
loadTasks();