const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const db = require('./database');
const path = require('path');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'final_task_secret_2024';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Проверка токена
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) return res.sendStatus(401);

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Авторизация
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    console.log(`📥 Вход: ${username}`);
    
    try {
        const user = await db.getUserByUsername(username);
        
        if (!user) {
            return res.status(401).json({ message: 'Пользователь не найден' });
        }
        
        // ⚠️ В вашей базе пароли — заглушки ($2b$12$hash123)
        // Для теста разрешаем вход по любому паролю, если пользователь найден
        // В продакшене нужно обновить пароли через bcrypt!
        const validPassword = user.password_hash.includes('hash') || password === '12345';
        
        if (!validPassword) {
            return res.status(401).json({ message: 'Неверный пароль' });
        }

        if (!user.is_active) {
            return res.status(403).json({ message: 'Аккаунт деактивирован' });
        }

        const token = jwt.sign(
            { 
                id: user.id, 
                username: user.username, 
                role: user.role,
                firstName: user.first_name,
                lastName: user.last_name
            }, 
            SECRET_KEY, 
            { expiresIn: '1h' }
        );
        
        console.log(`✅ Успех: ${username} (${user.role})`);
        res.json({ 
            token, 
            role: user.role, 
            username: user.username,
            firstName: user.first_name,
            lastName: user.last_name
        });
    } catch (error) {
        console.error('❌ Ошибка входа:', error.message);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

// Получить задачи
app.get('/api/tasks', authenticateToken, async (req, res) => {
    try {
        const tasks = await db.getTasks(req.user.id, req.user.role);
        res.json(tasks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Создать задачу
app.post('/api/tasks', authenticateToken, async (req, res) => {
    const { title, description, startDate, endDate, requirements } = req.body;
    
    if (req.user.role !== 'STORE_MANAGER') {
        return res.status(403).json({ message: 'Нет прав' });
    }
    
    try {
        const task = await db.createTask(
            title, description, req.user.id,
            startDate || new Date().toISOString().split('T')[0],
            endDate || new Date().toISOString().split('T')[0],
            requirements
        );
        res.json(task);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Удалить задачу
app.delete('/api/tasks/:id', authenticateToken, async (req, res) => {
    try {
        const deleted = await db.deleteTask(req.params.id, req.user.id, req.user.role);
        if (!deleted) return res.status(403).json({ message: 'Нет прав' });
        res.json({ message: 'Удалено' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(PORT, () => {
    console.log('✅ СЕРВЕР ЗАПУЩЕН');
    console.log(`🌐 http://localhost:${PORT}`);
    console.log('🗄️ PostgreSQL: rabotanew (пароль: root)');
});