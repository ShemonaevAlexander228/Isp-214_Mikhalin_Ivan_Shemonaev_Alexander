import requests
import json
import sys

# --- КОНФИГУРАЦИЯ ---
BASE_URL = "http://localhost:3000/api"
HEADERS = {"Content-Type": "application/json"}

# Тестовые пользователи из вашего задания
USERS = {
    "store": {"username": "store_mgr_1", "password": "12345"},
    "office": {"username": "office_mgr_1", "password": "12345"},
    "hr": {"username": "hr_1", "password": "12345"}
}

def print_section(title):
    """Красивый разделитель для консоли"""
    print("\n" + "="*60)
    print(f"📌 {title}")
    print("="*60)

def login(role_key):
    """Авторизация и получение токена"""
    user = USERS[role_key]
    print(f"\n🔐 Вход как {user['username']}...")
    
    response = requests.post(f"{BASE_URL}/login", json=user, headers=HEADERS)
    
    if response.status_code == 200:
        data = response.json()
        token = data.get('token')
        print(f"✅ Успешно! Токен получен.")
        print(f"   Роль: {data.get('role')}")
        return token
    else:
        print(f"❌ Ошибка входа: {response.status_code} - {response.text}")
        return None

def get_tasks(token):
    """GET запрос: Получение списка задач"""
    print("\n📥 Запрос списка задач (GET /tasks)...")
    headers = {**HEADERS, "Authorization": f"Bearer {token}"}
    
    response = requests.get(f"{BASE_URL}/tasks", headers=headers)
    
    if response.status_code == 200:
        tasks = response.json()
        print(f"✅ Найдено задач: {len(tasks)}")
        for t in tasks:
            print(f"   - [{t['status']}] {t['title']}")
        return tasks
    else:
        print(f"❌ Ошибка: {response.status_code}")
        return []

def create_task(token, title, desc="Тестовое описание"):
    """POST запрос: Создание задачи"""
    print(f"\n📤 Создание задачи: '{title}' (POST /tasks)...")
    headers = {**HEADERS, "Authorization": f"Bearer {token}"}
    
    payload = {
        "title": title,
        "description": desc,
        "startDate": "2024-01-01",
        "endDate": "2024-12-31",
        "requirements": "Без спец. требований"
    }
    
    response = requests.post(f"{BASE_URL}/tasks", json=payload, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Задача создана! ID: {data.get('id')}")
        return data.get('id')
    else:
        print(f"❌ Ошибка создания: {response.status_code} - {response.text}")
        return None

def delete_task(token, task_id):
    """DELETE запрос: Удаление задачи"""
    print(f"\n🗑️ Удаление задачи ID: {task_id} (DELETE /tasks/{task_id})...")
    headers = {**HEADERS, "Authorization": f"Bearer {token}"}
    
    response = requests.delete(f"{BASE_URL}/tasks/{task_id}", headers=headers)
    
    if response.status_code == 200:
        print(f"✅ Задача удалена успешно.")
        return True
    else:
        print(f"❌ Ошибка удаления: {response.status_code} - {response.text}")
        return False

def test_role_permissions():
    """Проверка прав доступа (US-1, US-3, US-7)"""
    print_section("ПРОВЕРКА ПРАВ ДОСТУПА ПО РОЛЯМ")
    
    # 1. Пробуем создать задачу за Офис-менеджера (должно быть запрещено)
    office_token = login("office")
    if office_token:
        create_task(office_token, "Задача от офиса (должна быть ошибка)")
    
    # 2. Пробуем создать задачу за HR (должно быть запрещено)
    hr_token = login("hr")
    if hr_token:
        create_task(hr_token, "Задача от HR (должна быть ошибка)")

def main():
    """Основной сценарий тестирования"""
    print("🚀 ЗАПУСК АВТОТЕСТОВ API")
    print(f"🌐 Целевой сервер: {BASE_URL}")
    
    # --- Сценарий 1: Store Manager (Полный цикл) ---
    print_section("СЦЕНАРИЙ 1: УПРАВЛЯЮЩИЙ МАГАЗИНОМ (Store Manager)")
    token = login("store")
    
    if token:
        # 1. Посмотреть текущие задачи
        get_tasks(token)
        
        # 2. Создать новую задачу (US-1)
        new_id = create_task(token, "Ремонт витрины", "Замена стекла")
        
        # 3. Удалить созданную задачу
        if new_id:
            delete_task(token, new_id)
            
        # 4. Проверить список снова
        get_tasks(token)
    
    # --- Сценарий 2: Проверка прав (Office & HR) ---
    test_role_permissions()
    
    # --- Сценарий 3: Office Manager (Просмотр) ---
    print_section("СЦЕНАРИЙ 2: УПРАВЛЯЮЩИЙ ОФИСОМ (Office Manager)")
    office_token = login("office")
    if office_token:
        get_tasks(office_token) # Должен видеть задачи со статусом NEW или NULL

    print_section("ТЕСТИРОВАНИЕ ЗАВЕРШЕНО")
    print("✅ Если все шаги прошли успешно — сервер работает корректно.")

if __name__ == "__main__":
    try:
        main()
    except requests.exceptions.ConnectionError:
        print("\n❌ ОШИБКА ПОДКЛЮЧЕНИЯ!")
        print("Убедитесь, что сервер запущен: node server.js")
        sys.exit(1)