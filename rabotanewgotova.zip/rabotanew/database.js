const { Pool } = require('pg');

// Подключение к PostgreSQL
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'rabotanew',
    password: 'root',  // ← Ваш пароль
    port: 5432,
});

// Проверка подключения
pool.connect((err, client, release) => {
    if (err) {
        console.error('❌ Ошибка подключения к БД:', err.message);
    } else {
        console.log('✅ PostgreSQL подключён: rabotanew');
        release();
    }
});

// Функции для работы с БД
const getUserByUsername = async (username) => {
    const result = await pool.query(
        'SELECT * FROM users WHERE username = $1',
        [username]
    );
    return result.rows[0];
};

const getTasks = async (userId, role) => {
    let queryText, params;
    
    if (role === 'STORE_MANAGER') {
        queryText = 'SELECT * FROM tasks WHERE store_manager_id = $1';
        params = [userId];
    } else if (role === 'OFFICE_MANAGER') {
        queryText = 'SELECT * FROM tasks WHERE office_manager_id = $1 OR office_manager_id IS NULL';
        params = [userId];
    } else {
        // HR_SPECIALIST видит все
        queryText = 'SELECT * FROM tasks';
        params = [];
    }
    
    const result = await pool.query(queryText, params);
    return result.rows;
};

const createTask = async (title, description, storeManagerId, startDate, endDate, requirements) => {
    const result = await pool.query(
        `INSERT INTO tasks (title, description, store_manager_id, start_date, end_date, requirements, status) 
         VALUES ($1, $2, $3, $4, $5, $6, 'NEW') RETURNING *`,
        [title, description, storeManagerId, startDate, endDate, requirements || '']
    );
    return result.rows[0];
};

const deleteTask = async (taskId, userId, role) => {
    let queryText, params;
    
    if (role === 'STORE_MANAGER') {
        queryText = 'DELETE FROM tasks WHERE id = $1 AND store_manager_id = $2';
        params = [taskId, userId];
    } else {
        queryText = 'DELETE FROM tasks WHERE id = $1';
        params = [taskId];
    }
    
    const result = await pool.query(queryText, params);
    return result.rowCount > 0;
};

module.exports = {
    pool,
    getUserByUsername,
    getTasks,
    createTask,
    deleteTask
};