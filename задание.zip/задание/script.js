// Обновленный script.js с обработчиками для всех кнопок

document.addEventListener('DOMContentLoaded', function() {
    console.log("Страница загружена, инициализируем...");
    
    // Инициализация навигации
    initNavigation();
    
    // Инициализация всех кнопок
    initAllButtons();
    
    // Инициализация форм
    initForms();
    
    // Инициализация модальных окон
    initModals();
    
    // Инициализация уведомлений
    initNotifications();
});

// Навигация по разделам
function initNavigation() {
    const navLinks = document.querySelectorAll('.sidebar a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            
            // Скрываем активный класс
            navLinks.forEach(l => {
                l.parentElement.classList.remove('active');
            });
            
            // Добавляем активный класс текущей ссылке
            this.parentElement.classList.add('active');
            
            // Скрываем все секции
            document.querySelectorAll('.main-content > section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Показываем целевую секцию
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.remove('hidden');
                console.log(`Переключено на раздел: ${targetId}`);
            }
        });
    });
}

// Инициализация всех кнопок
function initAllButtons() {
    // Кнопки фильтрации заданий
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const status = this.getAttribute('data-status');
            filterTasksByStatus(status);
        });
    });
    
    // Кнопка создания задания (для магазина)
    const createTaskBtn = document.getElementById('createTaskBtn');
    if (createTaskBtn) {
        createTaskBtn.addEventListener('click', function() {
            document.getElementById('dashboard')?.classList.add('hidden');
            document.getElementById('create-task')?.classList.remove('hidden');
            
            // Обновляем навигацию
            updateNavigation('#create-task');
        });
    }
    
    // Кнопка отправки задания в офис (US-2)
    const sendToOfficeBtn = document.getElementById('sendToOfficeBtn');
    if (sendToOfficeBtn) {
        sendToOfficeBtn.addEventListener('click', function() {
            const taskName = document.getElementById('task-name')?.value;
            const startDate = document.getElementById('start-date')?.value;
            const endDate = document.getElementById('end-date')?.value;
            const requirements = document.getElementById('requirements')?.value;
            
            if (!taskName || !startDate || !endDate || !requirements) {
                showNotification('Заполните все обязательные поля!', 'error');
                return;
            }
            
            showNotification('Задание успешно отправлено в офис! Статус изменен на "В работе"', 'success');
            
            // Переключаемся на список заданий
            document.getElementById('create-task')?.classList.add('hidden');
            document.getElementById('my-tasks')?.classList.remove('hidden');
            
            // Обновляем навигацию
            updateNavigation('#my-tasks');
        });
    }
    
    // Кнопки "Назначить" в таблице заданий
    document.querySelectorAll('.btn-assign').forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const taskId = row?.cells[0]?.textContent;
            const taskName = row?.cells[2]?.textContent;
            
            if (taskId && taskName) {
                showNotification(`Начинаем подбор специалистов для задания ${taskId}: "${taskName}"`, 'info');
                
                // Переключаемся на раздел специалистов
                document.getElementById('tasks-in-work')?.classList.add('hidden');
                document.getElementById('specialists')?.classList.remove('hidden');
                
                // Обновляем навигацию
                updateNavigation('#specialists');
                
                // Обновляем заголовок
                const subtitle = document.querySelector('.subtitle');
                if (subtitle) {
                    subtitle.innerHTML = `Текущее задание: <strong>${taskName}</strong>`;
                }
            }
        });
    });
    
    // Кнопки "Просмотреть" в таблице
    document.querySelectorAll('.tasks-table .btn-view').forEach(btn => {
        btn.addEventListener('click', function() {
            showNotification('Просмотр деталей задания', 'info');
        });
    });
    
    // Кнопки "Карточка" специалистов
    document.querySelectorAll('.specialist-actions .btn-view').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.specialist-card');
            const name = card?.querySelector('.specialist-header h3')?.textContent;
            const specialization = card?.querySelectorAll('.specialist-info p')[0]?.textContent.replace('Специализация:', '').trim();
            const experience = card?.querySelectorAll('.specialist-info p')[1]?.textContent.replace('Опыт:', '').trim();
            const rating = card?.querySelectorAll('.specialist-info p')[2]?.textContent.replace('Рейтинг:', '').trim();
            const status = card?.querySelector('.specialist-status')?.textContent;
            
            // Заполняем модальное окно
            if (name) {
                document.getElementById('modal-specialist-name').textContent = name;
                document.getElementById('modal-specialization').textContent = specialization || 'Не указано';
                document.getElementById('modal-experience').textContent = experience || 'Не указано';
                document.getElementById('modal-rating').textContent = rating || 'Не указано';
                document.getElementById('modal-status').textContent = status || 'Неизвестно';
                
                // Показываем модальное окно
                document.getElementById('specialistModal').classList.remove('hidden');
            }
        });
    });
    
    // Кнопки "Назначить" специалистов (US-5)
    document.querySelectorAll('.btn-assign-specialist').forEach(btn => {
        btn.addEventListener('click', function() {
            if (this.disabled) {
                showNotification('Специалист временно недоступен', 'warning');
                return;
            }
            
            const card = this.closest('.specialist-card');
            const specialistName = card?.querySelector('.specialist-header h3')?.textContent;
            
            if (specialistName) {
                showNotification(`Специалист ${specialistName} назначен на задание! (US-5)`, 'success');
                
                // Обновляем кнопку
                this.textContent = 'Назначен ✓';
                this.disabled = true;
                this.classList.remove('btn-primary');
                this.classList.add('btn-success');
            }
        });
    });
    
    // Кнопка создания заявки в HR (US-6)
    const createHrRequestBtn = document.getElementById('createHrRequestBtn');
    if (createHrRequestBtn) {
        createHrRequestBtn.addEventListener('click', function() {
            showNotification('Заявка на подбор персонала успешно создана! HR-специалисты уведомлены. (US-6)', 'success');
        });
    }
    
    // Кнопки редактирования задания
    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', function() {
            showNotification('Режим редактирования задания', 'info');
        });
    });
    
    // Кнопки отправки задания
    document.querySelectorAll('.btn-send').forEach(btn => {
        if (!btn.id) {
            btn.addEventListener('click', function() {
                showNotification('Задание отправлено на утверждение', 'success');
            });
        }
    });
    
    // Кнопки отмены задания (US-9)
    document.querySelectorAll('.btn-cancel').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.task-card');
            const taskName = card?.querySelector('.task-header h3')?.textContent;
            
            if (taskName && confirm(`Вы уверены, что хотите отменить задание "${taskName}"? (US-9)`)) {
                showNotification(`Задание "${taskName}" отменено`, 'info');
                
                // Обновляем статус
                const statusSpan = card.querySelector('.task-status');
                if (statusSpan) {
                    statusSpan.textContent = 'Отменено';
                    statusSpan.className = 'task-status cancelled';
                }
                
                // Отключаем кнопки
                card.querySelectorAll('button').forEach(b => {
                    b.disabled = true;
                });
            }
        });
    });
    
    // Кнопки закрытия задания (US-10)
    const confirmCloseBtn = document.getElementById('confirmCloseBtn');
    if (confirmCloseBtn) {
        confirmCloseBtn.addEventListener('click', function() {
            const comment = document.getElementById('close-comment')?.value;
            showNotification(`Задание закрыто${comment ? ' с комментарием' : ''}! (US-10)`, 'success');
            document.getElementById('closeTaskModal').classList.add('hidden');
        });
    }
    
    // Кнопки выхода
    document.querySelectorAll('.btn-logout').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            if (confirm('Вы уверены, что хотите выйти?')) {
                showNotification('Выход выполнен', 'info');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            }
        });
    });
    
    // Кнопки фильтра "Фильтровать" и "Найти"
    document.querySelectorAll('.btn-secondary').forEach(btn => {
        if (btn.textContent.includes('Фильтровать') || btn.textContent.includes('Найти')) {
            btn.addEventListener('click', function() {
                showNotification('Фильтры применены', 'info');
            });
        }
    });
}

// Инициализация форм
function initForms() {
    // Валидация форм при отправке
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#e74c3c';
                    isValid = false;
                } else {
                    field.style.borderColor = '';
                }
            });
            
            if (isValid) {
                showNotification('Форма успешно отправлена', 'success');
                this.reset();
            } else {
                showNotification('Заполните все обязательные поля', 'error');
            }
        });
    });
    
    // Сброс ошибок при вводе
    document.querySelectorAll('input, textarea, select').forEach(field => {
        field.addEventListener('input', function() {
            this.style.borderColor = '';
        });
    });
}

// Инициализация модальных окон
function initModals() {
    // Закрытие модального окна задания
    const cancelCloseBtn = document.getElementById('cancelCloseBtn');
    if (cancelCloseBtn) {
        cancelCloseBtn.addEventListener('click', function() {
            document.getElementById('closeTaskModal').classList.add('hidden');
        });
    }
    
    // Закрытие модального окна специалиста
    const closeModalBtn = document.getElementById('closeModalBtn');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', function() {
            document.getElementById('specialistModal').classList.add('hidden');
        });
    }
    
    // Назначение из модального окна
    const assignFromModalBtn = document.getElementById('assignFromModalBtn');
    if (assignFromModalBtn) {
        assignFromModalBtn.addEventListener('click', function() {
            const specialistName = document.getElementById('modal-specialist-name').textContent;
            showNotification(`Специалист ${specialistName} назначен из модального окна`, 'success');
            document.getElementById('specialistModal').classList.add('hidden');
        });
    }
    
    // Закрытие модальных окон по клику вне окна
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.add('hidden');
            }
        });
    });
}

// Инициализация уведомлений
function initNotifications() {
    // Уведомление уже встроено в функции
}

// Вспомогательные функции
function filterTasksByStatus(status) {
    const taskCards = document.querySelectorAll('.task-card');
    
    taskCards.forEach(card => {
        if (status === 'all' || card.getAttribute('data-status') === status) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
    
    showNotification(`Показаны задания: ${status === 'all' ? 'Все' : status}`, 'info');
}

function updateNavigation(targetHash) {
    const navLinks = document.querySelectorAll('.sidebar a');
    navLinks.forEach(l => {
        l.parentElement.classList.remove('active');
        if (l.getAttribute('href') === targetHash) {
            l.parentElement.classList.add('active');
        }
    });
}

function showNotification(message, type = 'info') {
    console.log(`Уведомление [${type}]: ${message}`);
    
    // Цвета по типам
    const colors = {
        'success': '#2ecc71',
        'error': '#e74c3c',
        'warning': '#f39c12',
        'info': '#3498db'
    };
    
    // Создаем уведомление
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background-color: ${colors[type] || colors.info};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease;
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Автоматическое удаление
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Добавляем стили для анимаций уведомлений
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background-color: #3498db;
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease;
        max-width: 400px;
        word-wrap: break-word;
    }
`;
document.head.appendChild(style);