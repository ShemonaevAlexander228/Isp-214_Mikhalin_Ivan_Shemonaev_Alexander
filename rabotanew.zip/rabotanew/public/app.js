// === ПРОВЕРКА АВТОРИЗАЦИИ ===
// localStorage: чтение данных
const token = localStorage.getItem('token');
const role = localStorage.getItem('role');
const username = localStorage.getItem('username');

if (!token) {
    window.location.href = 'login.html';
}

// === DOM: Отображение информации о пользователе ===
const userInfo = document.getElementById('userInfo');
userInfo.innerHTML = `👤 ${username} <span class="role-badge">${role === 'admin' ? 'Админ' : 'Пользователь'}</span>`;

// === DOM: Обработчик выхода ===
document.getElementById('logoutBtn').addEventListener('click', () => {
    // localStorage: очистка
    localStorage.clear();
    window.location.href = 'login.html';
});

// === ФУНКЦИЯ: Загрузка задач (Fetch GET) ===
async function loadTasks() {
    const container = document.getElementById('tasksContainer');
    container.innerHTML = '<div class="text-center">Загрузка...</div>';

    try {
        // Fetch: GET-запрос с токеном
        const response = await fetch('/api/tasks', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Ошибка загрузки задач');
        
        const tasks = await response.json();
        container.innerHTML = '';

        if (tasks.length === 0) {
            container.innerHTML = '<div class="alert alert-info">Задач пока нет</div>';
            return;
        }

        // DOM: Создание элементов списка
        tasks.forEach(task => {
            const col = document.createElement('div');
            col.className = 'col-md-6 col-lg-4';
            
            col.innerHTML = `
                <div class="card task-card shadow-sm">
                    <div class="card-body">
                        <h6 class="card-title fw-bold">${escapeHtml(task.title)}</h6>
                        <p class="card-text text-muted">${escapeHtml(task.description)}</p>
                        ${role === 'admin' ? `<small class="text-primary">ID: ${task.id}</small><br>` : ''}
                        <button class="btn btn-danger btn-sm mt-2 delete-btn" data-id="${task.id}">
                            🗑️ Удалить
                        </button>
                    </div>
                </div>
            `;
            
            container.appendChild(col);
        });

        // Делегирование событий (требование DOM)
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.getAttribute('data-id');
                deleteTask(id);
            });
        });

    } catch (error) {
        container.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
        if (error.message.includes('401') || error.message.includes('403')) {
            localStorage.clear();
            window.location.href = 'login.html';
        }
    }
}

// === ФУНКЦИЯ: Добавление задачи (Fetch POST) ===
document.getElementById('addBtn').addEventListener('click', async () => {
    const titleInput = document.getElementById('taskTitle');
    const descInput = document.getElementById('taskDesc');
    
    const title = titleInput.value.trim();
    const description = descInput.value.trim();

    if (!title) {
        alert('Введите название задачи!');
        return;
    }

    try {
        // Fetch: POST-запрос
        const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ title, description })
        });

        if (!response.ok) throw new Error('Не удалось создать задачу');

        // DOM: Очистка полей
        titleInput.value = '';
        descInput.value = '';
        
        // Обновление списка
        loadTasks();

    } catch (error) {
        alert(error.message);
    }
});

// === ФУНКЦИЯ: Удаление задачи (Fetch DELETE) ===
async function deleteTask(id) {
    if (!confirm('Вы уверены, что хотите удалить эту задачу?')) return;

    try {
        // Fetch: DELETE-запрос
        const response = await fetch(`/api/tasks/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Ошибка удаления');
        }

        loadTasks();

    } catch (error) {
        alert(error.message);
    }
}

// === Утилита: Защита от XSS ===
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// === Запуск при загрузке ===
loadTasks();