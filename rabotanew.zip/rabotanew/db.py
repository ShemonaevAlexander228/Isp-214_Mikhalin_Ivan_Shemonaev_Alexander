import zipfile
import xml.etree.ElementTree as ET
import os
import sys
from datetime import datetime

class BacpacViewer
    def __init__(self, bacpac_path)
        self.bacpac_path = bacpac_path
        self.extract_path = temp_bacpac_extract
        
    def check_file(self)
        Проверяем существование файла
        if not os.path.exists(self.bacpac_path)
            print(f❌ Файл '{self.bacpac_path}' не найден!)
            print(fТекущая папка {os.getcwd()})
            return False
        print(f✅ Файл найден {self.bacpac_path})
        print(f📊 Размер {os.path.getsize(self.bacpac_path)  1024.2f} KB)
        return True
    
    def extract_bacpac(self)
        Извлекаем .bacpac (это ZIP архив)
        print(fn📦 Извлечение файлов...)
        try
            with zipfile.ZipFile(self.bacpac_path, 'r') as zip_ref
                zip_ref.extractall(self.extract_path)
            print(f✅ Файлы извлечены в папку {self.extract_path})
            return True
        except Exception as e
            print(f❌ Ошибка извлечения {e})
            return False
    
    def read_origin_xml(self)
        Читаем основную информацию о БД
        origin_path = os.path.join(self.extract_path, origin.xml)
        if not os.path.exists(origin_path)
            return None
            
        tree = ET.parse(origin_path)
        root = tree.getroot()
        
        info = {}
        for elem in root.iter()
            if 'DatabaseName' in elem.tag
                info['database_name'] = elem.text
            if 'Version' in elem.tag
                info['version'] = elem.text
                
        return info
    
    def read_model_xml(self)
        Читаем модель базы данных (таблицы и колонки)
        model_path = os.path.join(self.extract_path, model.xml)
        if not os.path.exists(model_path)
            print(❌ Файл model.xml не найден)
            return None, None
            
        print(f📄 Чтение model.xml...)
        tree = ET.parse(model_path)
        root = tree.getroot()
        
        # Namespace для SQL Server
        ns = {'ssdt' 'httpschemas.microsoft.comsqlserverdacSerialization201202'}
        
        return root, ns
    
    def show_database_info(self, info)
        Показываем информацию о базе данных
        print(n + =70)
        print(📊 ИНФОРМАЦИЯ О БАЗЕ ДАННЫХ)
        print(=70)
        if info
            print(f   Имя БД {info.get('database_name', 'Неизвестно')})
            print(f   Версия {info.get('version', 'Неизвестно')})
        print(f   Дата просмотра {datetime.now().strftime('%d.%m.%Y %H%M%S')})
        print(=70)
    
    def show_tables(self, root, ns)
        Показываем все таблицы и их структуру
        print(n + =70)
        print(📋 ТАБЛИЦЫ В БАЗЕ ДАННЫХ)
        print(=70)
        
        # Ищем все таблицы
        tables = root.findall('.ssdtElement[@Type=SqlTable]', ns)
        
        if not tables
            print(⚠️ Таблицы не найдены!)
            return
        
        print(f   Найдено таблиц {len(tables)}n)
        
        for i, table in enumerate(tables, 1)
            # Получаем имя таблицы
            name_elem = table.find('ssdtProperty[@Name=Name]', ns)
            if name_elem is not None
                table_name = name_elem.text
                print(f{'='70})
                print(f   ТАБЛИЦА #{i} {table_name})
                print(f{'='70})
                
                # Ищем колонки таблицы
                columns = table.findall('.ssdtElement[@Type=SqlColumn]', ns)
                
                if columns
                    print(f   {'Колонка'30} {'Тип данных'25} {'Nullable'10})
                    print(f   {'-'65})
                    
                    for col in columns
                        col_name = col.find('ssdtProperty[@Name=Name]', ns)
                        col_type = col.find('ssdtProperty[@Name=Type]', ns)
                        col_nullable = col.find('ssdtProperty[@Name=IsNullable]', ns)
                        
                        if col_name is not None
                            name = col_name.text
                            type_text = col_type.text if col_type is not None else unknown
                            nullable = YES if col_nullable is not None and col_nullable.text == True else NO
                            print(f   {name30} {type_text25} {nullable10})
                else
                    print(   ⚠️ Колонки не найдены)
                
                print()
        
        print(=70)
    
    def show_summary(self, root, ns)
        Показываем общую статистику
        print(n + =70)
        print(📈 СТАТИСТИКА БАЗЫ ДАННЫХ)
        print(=70)
        
        # Считаем различные объекты
        tables = len(root.findall('.ssdtElement[@Type=SqlTable]', ns))
        views = len(root.findall('.ssdtElement[@Type=SqlView]', ns))
        procs = len(root.findall('.ssdtElement[@Type=SqlProcedure]', ns))
        functions = len(root.findall('.ssdtElement[@Type=SqlFunction]', ns))
        
        print(f   📄 Таблицы           {tables})
        print(f   👁️ Представления     {views})
        print(f   ⚙️ Хранимые процедуры {procs})
        print(f   🔧 Функции           {functions})
        print(=70)
    
    def show_files_list(self)
        Показываем список файлов внутри .bacpac
        print(fn📁 ФАЙЛЫ ВНУТРИ .BACPAC)
        print(-50)
        with zipfile.ZipFile(self.bacpac_path, 'r') as zip_ref
            for filename in zip_ref.namelist()
                print(f   📄 {filename})
        print(-50)
    
    def cleanup(self)
        Удаляем временные файлы
        import shutil
        if os.path.exists(self.extract_path)
            shutil.rmtree(self.extract_path)
            print(fn🗑️ Временные файлы удалены)
    
    def run(self)
        Запускаем полный анализ
        print(n + =70)
        print(🔍 BACPAC VIEWER - Просмотр структуры базы данных)
        print(=70 + n)
        
        if not self.check_file()
            return False
        
        self.show_files_list()
        
        if not self.extract_bacpac()
            return False
        
        # Информация о БД
        db_info = self.read_origin_xml()
        self.show_database_info(db_info)
        
        # Таблицы
        root, ns = self.read_model_xml()
        if root
            self.show_summary(root, ns)
            self.show_tables(root, ns)
        
        # Оставляем файлы для проверки (закомментируйте cleanup для отладки)
        # self.cleanup()
        
        print(n✅ Анализ завершён!)
        print(f📁 Извлечённые файлы остались в папке {self.extract_path})
        return True

# ============================================
# ЗАПУСК СКРИПТА
# ============================================
if __name__ == __main__
    # Укажите имя вашего файла
    BACPAC_FILE = rabota.bacpac
    
    # Если файл в другой папке, укажите полный путь
    # BACPAC_FILE = rCUsersstudent313Desktoprabota.bacpac
    
    viewer = BacpacViewer(BACPAC_FILE)
    viewer.run()
    
    print(n + =70)
    print(⚠️ ВАЖНО Этот скрипт показывает ТОЛЬКО СТРУКТУРУ БД (схему).)
    print(   Для просмотра РЕАЛЬНЫХ ДАННЫХ нужен SQL Server.)
    print(=70)