const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('./database');
const path = require('path');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'final_task_secret_2024';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- Middleware: Проверка токена ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Формат: "Bearer TOKEN"
    
    if (!token) {
        console.log('❌ Токен не предоставлен');
        return res.sendStatus(401);
    }

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) {
            console.log('❌ Ошибка верификации токена');
            return res.sendStatus(403);
        }
        req.user = user;
        next();
    });
};

// --- API: Авторизация (Login) ---
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    console.log(`📥 Попытка входа: ${username}`);

    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (err || !user) {
            return res.status(401).json({ message: 'Пользователь не найден' });
        }
        
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ message: 'Неверный пароль' });
        }

        // Создаём JWT токен
        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role }, 
            SECRET_KEY, 
            { expiresIn: '1h' }
        );
        
        console.log(`✅ Вход успешен: ${username} (${user.role})`);
        res.json({ token, role: user.role, username: user.username });
    });
});

// --- API: Получить задачи (GET) ---
app.get('/api/tasks', authenticateToken, (req, res) => {
    // Админ видит все, пользователь только свои
    const query = req.user.role === 'admin' 
        ? 'SELECT * FROM tasks' 
        : 'SELECT * FROM tasks WHERE userId = ?';
    const params = req.user.role === 'admin' ? [] : [req.user.id];

    db.all(query, params, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// --- API: Создать задачу (POST) ---
app.post('/api/tasks', authenticateToken, (req, res) => {
    const { title, description } = req.body;
    const userId = req.user.id;
    
    db.run(
        'INSERT INTO tasks (title, description, userId) VALUES (?, ?, ?)', 
        [title, description, userId], 
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ id: this.lastID, title, description, userId });
        }
    );
});

// --- API: Удалить задачу (DELETE) ---
app.delete('/api/tasks/:id', authenticateToken, (req, res) => {
    const taskId = req.params.id;
    
    // Админ может удалить любую, пользователь только свою
    const query = req.user.role === 'admin'
        ? 'DELETE FROM tasks WHERE id = ?'
        : 'DELETE FROM tasks WHERE id = ? AND userId = ?';
    const params = req.user.role === 'admin' ? [taskId] : [taskId, req.user.id];

    db.run(query, params, function(err) {
        if (err) return res.status(500).json({ error: err.message });
        if (this.changes === 0) return res.status(403).json({ message: 'Нет прав на удаление' });
        res.json({ message: 'Удалено успешно' });
    });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log('='.repeat(40));
    console.log(`✅ СЕРВЕР ЗАПУЩЕН`);
    console.log(`🌐 Адрес: http://localhost:${PORT}`);
    console.log(`📁 Папка public: ${path.join(__dirname, 'public')}`);
    console.log('='.repeat(40));
});