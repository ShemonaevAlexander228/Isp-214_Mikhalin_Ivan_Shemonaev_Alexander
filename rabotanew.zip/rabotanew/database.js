const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');

// Создаём файл базы данных tasks.db
const db = new sqlite3.Database('./tasks.db', (err) => {
    if (err) {
        console.error('❌ Ошибка подключения к БД:', err.message);
    } else {
        console.log('✅ Подключение к SQLite успешно');
    }
});

db.serialize(() => {
    // Таблица пользователей
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT
    )`);

    // Таблица задач
    db.run(`CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        userId INTEGER
    )`);

    // Создаём тестовых пользователей (пароль: 12345)
    const hash = bcrypt.hashSync('12345', 10);
    
    db.run(`INSERT OR IGNORE INTO users (username, password, role) VALUES ('admin', '${hash}', 'admin')`);
    db.run(`INSERT OR IGNORE INTO users (username, password, role) VALUES ('user', '${hash}', 'user')`);
    
    console.log('👥 Тестовые пользователи созданы (admin/user : 12345)');
});

module.exports = db;